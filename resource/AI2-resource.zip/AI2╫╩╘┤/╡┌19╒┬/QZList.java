package com.qzlist.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;
import com.google.appinventor.components.runtime.util.YailList;

import android.content.Context;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collection;

@DesignerComponent(version = QZList.VERSION,                           
    description = "功能：列表处理  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)   
public class QZList extends AndroidNonvisibleComponent {                                         
    public static final int VERSION = 1;                        
    private ComponentContainer container;                        
    private Context context;

    private static final String LOG_TAG = "QZList";       
    public QZList(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();   

        Log.d(LOG_TAG, "QZList Created" );                 
    }

    @SimpleFunction(description = "把包含分隔符的字符串按分隔符分解，并转成列表")
    public static YailList ListCreate(String itemString, String separator){
        YailList items = new YailList();
        if (itemString.length() > 0) {
            items = YailList.makeList((Object[]) itemString.split(separator));
        }

        return items;
    }


    @SimpleFunction(description = "列表升序排序")
    public YailList ListSort(YailList list, boolean isNumber) {
        if (!isNumber){
            Object[] objectsArray = list.toArray();
            java.util.List objectsList = Arrays.asList(objectsArray);  
            java.util.Collections.sort(objectsList); 

            return YailList.makeList(objectsList);   
        } else {
            Object[] objectsArray = list.toArray();

            java.util.List <Double> doublesArray = new ArrayList<Double>();

            for(int i = 0; i < objectsArray.length; i++){
                doublesArray.add(Double.parseDouble(objectsArray[i].toString()));
            }

            java.util.Collections.sort(doublesArray); 

            return YailList.makeList(doublesArray);   
        }   
    }

    @SimpleFunction(description = "列表降序排序")
    public YailList ListReverse(YailList list, boolean isNumber) {
        if (!isNumber){
            Object[] objectsArray = list.toArray();
            java.util.List objectsList = Arrays.asList(objectsArray);  
            java.util.Collections.sort(objectsList);    
            java.util.Collections.reverse(objectsList);

            return YailList.makeList(objectsList);
        } else {
            Object[] objectsArray = list.toArray();

            java.util.List <Double> doublesArray = new ArrayList<Double>();

            for(int i = 0; i < objectsArray.length; i++){
                doublesArray.add(Double.parseDouble(objectsArray[i].toString()));
            }

            java.util.Collections.sort(doublesArray); 
            java.util.Collections.reverse(doublesArray);

            return YailList.makeList(doublesArray);   
        }   
    }

    @SimpleFunction(description = "列表最大值")
    public Object ListMax(YailList list, boolean isNumber) {
        if (!isNumber){
            Object[] objectsArray = list.toArray();
            java.util.List objectsList = Arrays.asList(objectsArray);  
            return java.util.Collections.max(objectsList);    
        } else {
            Object[] objectsArray = list.toArray();

            java.util.List <Double> doublesArray = new ArrayList<Double>();

            for(int i = 0; i < objectsArray.length; i++){
                doublesArray.add(Double.parseDouble(objectsArray[i].toString()));
            }

            return java.util.Collections.max(doublesArray); 
        }   
    }

    @SimpleFunction(description = "列表最小值")
    public Object ListMin(YailList list, boolean isNumber) {
        if (!isNumber){
            Object[] objectsArray = list.toArray();
            java.util.List objectsList = Arrays.asList(objectsArray);  
            return java.util.Collections.min(objectsList);   
        } else {
            Object[] objectsArray = list.toArray();

            java.util.List <Double> doublesArray = new ArrayList<Double>();

            for(int i = 0; i < objectsArray.length; i++){
                doublesArray.add(Double.parseDouble(objectsArray[i].toString()));
            }

            return java.util.Collections.min(doublesArray); 
        }    
    }
}