package com.torch.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;

import android.content.Context;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;

@DesignerComponent(version = Torch.VERSION,                           
    description = "功能：手电筒  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)   
@UsesPermissions(permissionNames = "android.permission.CAMERA, android.permission.FLASHLIGHT")   
public class Torch extends AndroidNonvisibleComponent implements OnDestroyListener {                                         
    public static final int VERSION = 1;                        
    private ComponentContainer container;                        
    private Context context;

    private Camera camera;

    private static final String LOG_TAG = "Torch";       
    public Torch(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();   

        Log.d(LOG_TAG, "Torch Created" );                 
    }

    @Override
    public void onDestroy() {
        if(camera != null){
            camera.stopPreview();  
            camera.release();   
        }
    }

    @SimpleFunction(description = "打开手电筒")
    public void TorchOn() {
        camera = Camera.open();  

        Parameters params = camera.getParameters();   
        params.setFlashMode(Parameters.FLASH_MODE_TORCH); 

        camera.setParameters(params);
        camera.startPreview();      
    }

    @SimpleFunction(description = "关闭手电筒")
    public void TorchOff() {
        if(camera != null){
            Parameters params = camera.getParameters();  
            params.setFlashMode(Parameters.FLASH_MODE_OFF);

            camera.setParameters(params);   
            camera.startPreview();  
        }
    }
}