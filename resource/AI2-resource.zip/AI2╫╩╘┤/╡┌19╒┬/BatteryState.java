package com.batterystate.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

@DesignerComponent(version = BatteryState.VERSION,                           
    description = "功能：监控电量状态  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)
@UsesPermissions(permissionNames = "android.permission.BATTERY_STATS")        
public class BatteryState extends AndroidNonvisibleComponent implements Component, OnDestroyListener {                                          
    public static final int VERSION = 1;                        
    private ComponentContainer container;                        
    private Context context;
    private final BatteryStateReceiver batteryStateReceiver;

    private static final String LOG_TAG = "BatteryState";       
    public BatteryState(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();   

        form.registerForOnDestroy(this);
        batteryStateReceiver = new BatteryStateReceiver();
        registerBatteryStateMonitor();    

        Log.d(LOG_TAG, "BatteryState Created" );                 
    }
    
    private class BatteryStateReceiver extends BroadcastReceiver {
        public BatteryStateReceiver() {
        
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(Intent.ACTION_BATTERY_LOW.equals(action)){
                BatteryStateLow();
            } else if (Intent.ACTION_BATTERY_OKAY.equals(action)) {
                BatteryStateOK();
            }else if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                int currentLevel = intent.getExtras().getInt("level");// 获得当前电量
                int total = intent.getExtras().getInt("scale");// 获得总电量
                int percent = currentLevel * 100 / total;
                BatteryLevel(percent);
            }
        }
    }

  /**
   * Registers battery state monitor
   */
  private void registerBatteryStateMonitor(){
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction(Intent.ACTION_BATTERY_LOW);
    intentFilter.addAction(Intent.ACTION_BATTERY_OKAY);
    intentFilter.addAction(Intent.ACTION_BATTERY_CHANGED);
    context.registerReceiver(batteryStateReceiver, intentFilter);
  }

  /**
   * Unregisters battery state monitor
   */
  private void unregisterBatteryStateMonitor(){
    context.unregisterReceiver(batteryStateReceiver);
  }

  @Override
  public void onDestroy() {
    unregisterBatteryStateMonitor();
  }

  @SimpleEvent(description = "反馈电量不足")
  public void BatteryStateLow() {
    EventDispatcher.dispatchEvent(this, "BatteryStateLow");
  }

  @SimpleEvent(description = "反馈电量充足")
  public void BatteryStateOK() {
    EventDispatcher.dispatchEvent(this, "BatteryStateOK");
  }

  @SimpleEvent(description = "反馈电量百分比")
  public void BatteryLevel(int level) {
    EventDispatcher.dispatchEvent(this, "BatteryLevel", level);
  }

}