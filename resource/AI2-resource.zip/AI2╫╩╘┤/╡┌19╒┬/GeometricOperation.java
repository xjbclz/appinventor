package com.geometricoperation.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;
import com.google.appinventor.components.runtime.util.YailList;

import android.content.Context;
import java.util.Arrays;
import java.util.ArrayList;
import java.lang.String;

@DesignerComponent(version = GeometricOperation.VERSION,                           
    description = "功能：几何运算  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)   
public class GeometricOperation extends AndroidNonvisibleComponent {                                         
    public static final int VERSION = 1;                        
    private ComponentContainer container;                        
    private Context context;

    private static final String LOG_TAG = "GeometricOperation";       
    public GeometricOperation(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();   

        Log.d(LOG_TAG, "GeometricOperation Created" );                 
    }

    @SimpleFunction(description = "矩形面积")
    public double RectangularArea(double width, double height) {
        return (width * height);
    }

    @SimpleFunction(description = "三角形面积")
    public double TriangleArea(double bottom, double height) {
        return (bottom * height / 2);
    }

    @SimpleFunction(description = "三角形面积")
    public double TriangleArea2(double sideLength1, double sideLength2, double angle) {
        return (sideLength1 * sideLength2 * Math.sin(angle)/ 2);
    }

    @SimpleFunction(description = "圆形面积")
    public double CircularArea(double radius, double pi) {
        return (pi * radius * radius);
    }

    @SimpleFunction(description = "椭圆面积")
    public double EllipticalArea(double longAxis, double shortAxis, double pi) {
        return (pi * longAxis * shortAxis / 4);
    }

    @SimpleFunction(description = "梯形面积")
    public double TrapezoidalArea(double top, double bottom, double height) {
        return ((top + bottom) * height / 2);
    }

    @SimpleFunction(description = "立方体表面积")
    public double CubicArea(double length, double width, double height) {
        return (length * width * 2 + length * height * 2 + width * height * 2);
    }

    @SimpleFunction(description = "立方体体积")
    public double CubicVolume(double length, double width, double height) {
        return (length * width * height);
    }

    @SimpleFunction(description = "圆柱体表面积")
    public double CylinderArea(double radius, double height, double pi) {
        return (pi * radius * radius * 2 + pi * radius * 2 * height);
    }

    @SimpleFunction(description = "圆柱体体积")
    public double CylinderVolume(double radius, double height, double pi) {
        return (pi * radius * radius * height);
    }

    @SimpleFunction(description = "球体表面积")
    public double SphereArea(double radius, double pi) {
        return (pi * radius * radius * 4);
    }  

    @SimpleFunction(description = "球体体积")
    public double SphereVolume(double radius, double pi) {
        return ((pi * radius * radius * radius * 4) / 3);
    }  
}