package com.algebraicoperation.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;
import com.google.appinventor.components.runtime.util.YailList;

import android.content.Context;
import java.util.Arrays;
import java.util.ArrayList;
import java.lang.String;

@DesignerComponent(version = AlgebraicOperation.VERSION,                           
    description = "功能：代数运算  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)   
public class AlgebraicOperation extends AndroidNonvisibleComponent {                                         
    public static final int VERSION = 1;                        
    private ComponentContainer container;                        
    private Context context;
    private double real;
    private double imag;

    private static final String LOG_TAG = "AlgebraicOperation";       
    public AlgebraicOperation(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();   

        Log.d(LOG_TAG, "AlgebraicOperation Created" );                 
    }

    @SimpleFunction(description = "矩阵相加")
    public YailList MatrixAdd(YailList list1, YailList list2) {
        java.util.List<Double> resultsList = new ArrayList<Double>();

        Object[] objectsArray1 = list1.toArray();
        Object[] objectsArray2 = list2.toArray();

        if ((list1.size() == list2.size()) && (list1.size() > 0)){
            for (int i = 0; i < list1.size(); i++){
                resultsList.add(new Double(objectsArray1[i].toString()) + new Double(objectsArray2[i].toString()));
            }  

            return YailList.makeList(resultsList);   
        } else {
            return null;
        }

    }

    @SimpleFunction(description = "矩阵相减")
    public YailList MatrixSub(YailList list1, YailList list2) {
        java.util.List<Double> resultsList = new ArrayList<Double>();

        Object[] objectsArray1 = list1.toArray();
        Object[] objectsArray2 = list2.toArray();

        if ((list1.size() == list2.size()) && (list1.size() > 0)){
            for (int i = 0; i < list1.size(); i++){
                resultsList.add(new Double(objectsArray1[i].toString()) - new Double(objectsArray2[i].toString()));
            }  

            return YailList.makeList(resultsList);   
        } else {
            return null;
        }
    }

    @SimpleFunction(description = "复数运算：+、-、x、/")
    public void Complex(double real1, double imag1, double real2, double imag2, String operator) {
        if (operator.equals("+")){
            complexAdd(real1, imag1, real2, imag2);
        }

        if (operator.equals("-")){
            complexSub(real1, imag1, real2, imag2);
        }

        if (operator.equals("x")){
            complexMul(real1, imag1, real2, imag2);
        }

        if (operator.equals("/")){
            complexDiv(real1, imag1, real2, imag2);
        }

        ComplexResult(real, imag);
    }

    @SimpleFunction(description = "复数的模")
    public double ComplexModel(double real, double imag) {
        return Math.sqrt(real * real + imag * imag);
    }


    @SimpleEvent(description = "反馈计算结果")
    public void ComplexResult(double real, double imag) {
        EventDispatcher.dispatchEvent(this, "ComplexResult", real, imag);
    }

    public void complexAdd(double real1, double imag1, double real2, double imag2) {
        real = real1 + real2;
        imag = imag1 + imag2;
    }

    public void complexSub(double real1, double imag1, double real2, double imag2) {
        real = real1 - real2;
        imag = imag1 - imag2;
    }

    public void complexMul(double real1, double imag1, double real2, double imag2) {
        real = real1 * real2 - imag1 * imag2;
        imag = imag1 * real2 + real1 * imag2; 
    }

    public void complexDiv(double real1, double imag1, double real2, double imag2) {
        real = (real1 * real2 + imag * imag2) / (real2 * real2 + imag2 * imag2);  
        imag = (imag1 * real2 - real1 * imag2) / (real2 * real2 + imag2 * imag2); 
    }
}