package com.systemsettings.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;

import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

@DesignerComponent(version = SystemSettings.VERSION,                           
    description = "功能：跳转到系统设置界面  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)   
public class SystemSettings extends AndroidNonvisibleComponent {                                          
    public static final int VERSION = 1;                        
    private ComponentContainer container;                        
    private Context context;

    private static final String LOG_TAG = "SystemSettings";       
    public SystemSettings(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();   

        Log.d(LOG_TAG, "SystemSettings Created" );                 
    }

    @SimpleFunction(description = "跳转到系统设置界面")
    public void SystemSettings() {
        Intent intent = new Intent(Settings.ACTION_SETTINGS);  
        context.startActivity(intent);
    }

    @SimpleFunction(description = "跳转到无线和网络设置界面")
    public void WirelessSettings() {
       Intent intent = new Intent(Settings.ACTION_WIRELESS_SETTINGS);  
       context.startActivity(intent);
    }
}