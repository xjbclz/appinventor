package com.mobilephonenumber.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;

import android.content.Context;

@DesignerComponent(version = MobilePhoneNumber.VERSION,                           
    description = "功能：验证手机号码格式  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)   
public class MobilePhoneNumber extends AndroidNonvisibleComponent {                                         
    public static final int VERSION = 1;                        
    private ComponentContainer container;                        
    private Context context;

    private static final String LOG_TAG = "MobilePhoneNumber";       
    public MobilePhoneNumber(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();   

        Log.d(LOG_TAG, "MobilePhoneNumber Created" );                 
    }

    @SimpleFunction(description = "验证手机号码格式是否正确，返回值为true或false")
    public boolean IsMobilePhoneNumber(String phoneNumber) {  
        String phoneNumberRegularExpression = "[1][3578]\\d{9}";

        if (phoneNumber == null || phoneNumber.length() != 11)
        {
            return false;
        }

        return phoneNumber.matches(phoneNumberRegularExpression);
    }
}