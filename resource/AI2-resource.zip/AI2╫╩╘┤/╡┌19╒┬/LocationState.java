package com.locationstate.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;

import android.location.LocationManager;

@DesignerComponent(version = LocationState.VERSION,                           
    description = "功能：获取定位功能状态  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)   
@UsesPermissions(permissionNames = "android.permission.ACCESS_FINE_LOCATION")        
public class LocationState extends AndroidNonvisibleComponent {                                         
    public static final int VERSION = 1;                        
    private ComponentContainer container;    
    private Context context;                    
  
    private static final String LOG_TAG = "LocationState";       
    public LocationState(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();   

        Log.d(LOG_TAG, "LocationState Created" );                 
    }

    @SimpleFunction(description = "获取定位功能状态，返回值为：开启或关闭")
    public String GetLocationState() {
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        // 通过GPS卫星定位，适用于在室外定位
        boolean gpsProvider = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        // 通过基站或WiFi定位，室内室外都可用
        boolean networkProvider = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        if (gpsProvider || networkProvider) {
            return "开启";
        }

        return "关闭";
    }
}