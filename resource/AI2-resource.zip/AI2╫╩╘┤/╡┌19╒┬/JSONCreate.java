package com.jsoncreate.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;

import org.json.JSONException;
import org.json.JSONObject;

@DesignerComponent(version = JSONCreate.VERSION,                           
    description = "功能：创建JSON字符串  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)         
public class JSONCreate extends AndroidNonvisibleComponent {                                         
    public static final int VERSION = 1;                        
    private ComponentContainer container;    
    private Context context;    
    private JSONObject obj;                  
  
    private static final String LOG_TAG = "JSONCreate";       
    public JSONCreate(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();   

        Log.d(LOG_TAG, "JSONCreate Created" );                 
    }

    @SimpleFunction(description = "创建JSON对象")
    public void CreateJSONObject() {
        obj = new JSONObject();
    }

    @SimpleFunction(description = "添加boolean类型元素")
    public void PutBooleanValue(String name, boolean booleanValue) {
        try {
            obj.put(name, booleanValue);
        }catch (JSONException e)
        {
            e.printStackTrace();
        }
    }

    @SimpleFunction(description = "添加double类型元素")
    public void PutDoubleValue(String name, double doubleValue) {
        try {
            obj.put(name, doubleValue);
        }catch (JSONException e)
        {
            e.printStackTrace();
        }
    }

    @SimpleFunction(description = "添加int类型元素")
    public void PutIntValue(String name, int intValue) {
        try {
            obj.put(name, intValue);
        }catch (JSONException e)
        {
            e.printStackTrace();
        }
    }

    @SimpleFunction(description = "添加long类型元素")
    public void PutLongValue(String name, long longValue) {
        try {
            obj.put(name, longValue);
        }catch (JSONException e)
        {
            e.printStackTrace();
        }
    }

    @SimpleFunction(description = "添加Object类型元素")
    public void PutObjectValue(String name, Object objectValue) {
        try {
            obj.put(name, objectValue);
        }catch (JSONException e)
        {
            e.printStackTrace();
        }
    }

    @SimpleFunction(description = "移除元素")
    public void Remove(String name) {
        obj.remove(name);
    }

    @SimpleFunction(description = "把JSON格式数据转成String类型数据")
    public String JSONtoString() {
        return String.valueOf(obj);
    }
}