package com.encryption.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@DesignerComponent(version = Encryption.VERSION,                           
    description = "功能：数据加密  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)        
public class Encryption extends AndroidNonvisibleComponent    
implements Component {                                           
    public static final int VERSION = 1;                        
    private ComponentContainer container;                        
    private Context context;                                     
    private static final String LOG_TAG = "Encryption";       
    public Encryption(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();                
        Log.d(LOG_TAG, "Encryption Created" );                 
    }
    
    @SimpleFunction(description = "对数据进行MD5加密")
    public String makeMD5Hash(String srcStr) {
	  String MD5Str;
	  try {
		  final MessageDigest mDigest = MessageDigest.getInstance("MD5");
		  mDigest.reset();
		  mDigest.update(srcStr.getBytes());
		  MD5Str = bytesToHexString(mDigest.digest());
	  } catch (NoSuchAlgorithmException e) {
		  MD5Str = String.valueOf(srcStr.hashCode());
	  }
	  return MD5Str;
  }
  
  private String bytesToHexString(byte[] bytes) {
	  StringBuilder sb = new StringBuilder();
	  for (byte value : bytes) {
		  String hex = Integer.toHexString(0xFF & value);
		  if (hex.length() == 1) {
			  sb.append('0');
		  }
		  sb.append(hex);
	  }
	  return sb.toString();
  }
}