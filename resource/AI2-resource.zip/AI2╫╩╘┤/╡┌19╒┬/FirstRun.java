package com.firstrun.extensions;

import android.content.Context;
import android.util.Log;
import com.google.appinventor.components.annotations.*;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;
import com.google.appinventor.components.runtime.util.*;

import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import android.content.SharedPreferences;
import org.json.JSONException;

@DesignerComponent(version = FirstRun.VERSION,
    description = "功能：判断App是否第一次运行  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,
    nonVisible = true,
    iconName = "images/extension.png")

@SimpleObject(external = true)
public class FirstRun extends AndroidNonvisibleComponent implements Component {
    public static final int VERSION = 1;
    private ComponentContainer container;
    private Context context;
    private SharedPreferences sharedPreferences;
    private final String tag = "FirstRun";
    private static final String LOG_TAG = "FirstRun";

    public FirstRun(ComponentContainer container) {
        super(container.$form());
        this.container = container;
        context = (Context) container.$context();
        Log.d(LOG_TAG, "FirstRun Created" );
        sharedPreferences = context.getSharedPreferences("FirstRun", Context.MODE_PRIVATE);
    }
    
    @SimpleFunction(description = "判断App是否第一次运行，返回值为true或false")
    public boolean IsFirstRun() {
    	if (GetValue(tag, "yes") == "yes") {
    		StoreValue(tag, "no");
    		return true;
    	}else{
    		return false;
    	}
    }

    @SimpleFunction(description = "清除记录是否第一次运行的标识")
    public void ClearFirstRunFlag() {
    	final SharedPreferences.Editor sharedPrefsEditor = sharedPreferences.edit();
    	sharedPrefsEditor.clear();
    	sharedPrefsEditor.commit();
    }

    public Object GetValue(final String tag, final Object valueIfTagNotThere) {
    	try {
    		String value = sharedPreferences.getString(tag, "");
    		// If there's no entry with tag as a key then return the empty string.
    		//    was  return (value.length() == 0) ? "" : JsonUtil.getObjectFromJson(value);
    		return (value.length() == 0) ? valueIfTagNotThere : JsonUtil.getObjectFromJson(value);
    	} catch (JSONException e) {
    		throw new YailRuntimeError("Value failed to convert from JSON.", "JSON Creation Error.");
    	}
    }
    
    public void StoreValue(final String tag, final Object valueToStore) {
    	final SharedPreferences.Editor sharedPrefsEditor = sharedPreferences.edit();
    	try {
    		sharedPrefsEditor.putString(tag, JsonUtil.getJsonRepresentation(valueToStore));
    		sharedPrefsEditor.commit();
    	} catch (JSONException e) {
    		throw new YailRuntimeError("Value failed to convert to JSON.", "JSON Creation Error.");
    	}
    }
}
