package com.airplanestate.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.provider.Settings;

@DesignerComponent(version = AirPlaneState.VERSION,                           
    description = "功能：获取和监控飞行模式状态  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)   
public class AirPlaneState extends AndroidNonvisibleComponent implements Component, OnDestroyListener {                                          
    public static final int VERSION = 1;                        
    private ComponentContainer container;                        
    private Context context;
    private final AirPlaneStateReceiver airPlaneStateReceiver;

    private static final String LOG_TAG = "AirPlaneState";       
    public AirPlaneState(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();   

        form.registerForOnDestroy(this);
        airPlaneStateReceiver = new AirPlaneStateReceiver();
        registerAirPlaneStateMonitor();    

        Log.d(LOG_TAG, "AirPlaneState Created" );                 
    }
    
    private class AirPlaneStateReceiver extends BroadcastReceiver {
        public AirPlaneStateReceiver() {
        
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(Intent.ACTION_AIRPLANE_MODE_CHANGED.equals(action)){
               boolean state = intent.getExtras().getBoolean("state");
               if (state){
                   AirPlaneState("开启");
               } else {
                   AirPlaneState("关闭");
               }
            }
        }
    }

  private void registerAirPlaneStateMonitor(){
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
    context.registerReceiver(airPlaneStateReceiver, intentFilter);
  }

  private void unregisterAirPlaneStateMonitor(){
    context.unregisterReceiver(airPlaneStateReceiver);
  }

  @Override
  public void onDestroy() {
    unregisterAirPlaneStateMonitor();
  }

  @SimpleEvent(description = "反馈飞行模式状态，参数值为：开启、关闭")
  public void AirPlaneState(String state) {
    EventDispatcher.dispatchEvent(this, "AirPlaneState", state);
  }

  @SimpleFunction(description = "获取飞行模式状态，返回值为：开启、关闭")
  public String GetAirPlaneState() {
    int state = Settings.System.getInt(context.getContentResolver(), Settings.System.AIRPLANE_MODE_ON, 0);    
    if (state == 1){
        return "开启";
    } else {
        return "关闭";
    }
  }

}