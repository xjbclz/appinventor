package com.systeminfo.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.runtime.*;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import java.text.SimpleDateFormat;
import java.util.Date;

@DesignerComponent(version = SystemInfo.VERSION,                           
    description = "功能：获取设备和系统信息  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)   
@UsesPermissions(permissionNames = "android.permission.READ_PHONE_STATE")
public class SystemInfo extends AndroidNonvisibleComponent {                                         
    public static final int VERSION = 1;                        
    private ComponentContainer container;                        
    private Context context;

    private static final String LOG_TAG = "SystemInfo";       
    public SystemInfo(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();   

        Log.d(LOG_TAG, "SystemInfo Created" );                 
    }

    @SimpleFunction(description = "获取设备型号")
    public String GetModel() {  
        return android.os.Build.MODEL;
    }

    @SimpleFunction(description = "获取设备的IMEI号")
    public String GetIMEI() {  
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        return tm.getDeviceId();
    }

    @SimpleFunction(description = "获取屏幕的宽度")
    public int GetWidth() {  
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        return wm.getDefaultDisplay().getWidth();
    }

    @SimpleFunction(description = "获取屏幕的高度")
    public int GetHeight() {  
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        return wm.getDefaultDisplay().getHeight();
    }

    @SimpleFunction(description = "获取屏幕的DPI")
    public int GetDPI() {  
        return context.getResources().getDisplayMetrics().densityDpi;
    }

    @SimpleFunction(description = "获取系统的API级别")
    public String GetSysAPI() {  
        return android.os.Build.VERSION.SDK;
    }

    @SimpleFunction(description = "获取系统的版本")
    public String GetSysVersion() {  
        return android.os.Build.VERSION.RELEASE;
    }

    @SimpleFunction(description = "获取系统当前时间")
    public String GetSysTime() {  
        long time=System.currentTimeMillis();
        Date date=new Date(time);  
        SimpleDateFormat format=new SimpleDateFormat("yyyyMMddHHmmss");

        return format.format(date);
    }

    @SimpleFunction(description = "获取当前运行的App的版本")
    public String GetAppVersion() {  
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo packageInfo = pm.getPackageInfo(context.getPackageName(),PackageManager.GET_CONFIGURATIONS);
        
            return packageInfo.versionName;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
}