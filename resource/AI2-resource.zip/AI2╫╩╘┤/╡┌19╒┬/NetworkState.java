package com.networkstate.extension;    

import android.content.Context;     
import android.util.Log;            
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.*;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

@DesignerComponent(version = NetworkState.VERSION,                           
    description = "功能：获取和监控网络状态  开发者：QZ",     
    helpUrl = "http://blog.csdn.net/xjbclz",
    category = ComponentCategory.EXTENSION,                                
    nonVisible = true,                                                     
    iconName = "images/extension.png") 

@SimpleObject(external = true)
@UsesPermissions(permissionNames = "android.permission.ACCESS_NETWORK_STATE")        
public class NetworkState extends AndroidNonvisibleComponent implements Component, OnDestroyListener {                                          
    public static final int VERSION = 1;                        
    private ComponentContainer container;                        
    private Context context;
    private final NetworkStateReceiver networkStateReceiver;
    private String networkState;

    private static final String LOG_TAG = "NetworkState";       
    public NetworkState(ComponentContainer container) {          
        super(container.$form());                                
        this.container = container;                              
        context = (Context) container.$context();   

        form.registerForOnDestroy(this);
        networkStateReceiver = new NetworkStateReceiver();
        registerNetworkStateMonitor();    

        Log.d(LOG_TAG, "NetworkState Created" );                 
    }
    
    private class NetworkStateReceiver extends BroadcastReceiver {
        public NetworkStateReceiver() {
        
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(ConnectivityManager.CONNECTIVITY_ACTION.equals(action)){
               networkState = getNetworkState(context);

               NetworkState(networkState);
            }
        }
    }

    public String getNetworkState(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if (networkInfo != null) {
                if (networkInfo.isConnected()) {
                    int type = networkInfo.getType();

                    if (type == ConnectivityManager.TYPE_WIFI) {
                        return "WIFI";
                    } else if (type == ConnectivityManager.TYPE_MOBILE) {
                        return getNetworkClass(context);
                    }
                } else {
                    return "未连接网络";
                }
            } 
            
            return "未连接网络";
    }

    public String getNetworkClass(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);

        switch (telephonyManager.getNetworkType()) {
            case TelephonyManager.NETWORK_TYPE_GPRS:
            case TelephonyManager.NETWORK_TYPE_EDGE:
            case TelephonyManager.NETWORK_TYPE_CDMA:
            case TelephonyManager.NETWORK_TYPE_1xRTT:
            case TelephonyManager.NETWORK_TYPE_IDEN:
            {
                return "2G";
            }

            case TelephonyManager.NETWORK_TYPE_UMTS:
            case TelephonyManager.NETWORK_TYPE_EVDO_0:
            case TelephonyManager.NETWORK_TYPE_EVDO_A:
            case TelephonyManager.NETWORK_TYPE_HSDPA:
            case TelephonyManager.NETWORK_TYPE_HSUPA:
            case TelephonyManager.NETWORK_TYPE_HSPA:
            case TelephonyManager.NETWORK_TYPE_EVDO_B:
            case TelephonyManager.NETWORK_TYPE_EHRPD:
            case TelephonyManager.NETWORK_TYPE_HSPAP:
            {
                return "3G";
            }

            case TelephonyManager.NETWORK_TYPE_LTE:
            {
                return "4G";
            }

            default:
                return "未知网络"; 
        }
    }

  /**
   * Registers network state monitor
   */
  private void registerNetworkStateMonitor(){
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
    context.registerReceiver(networkStateReceiver, intentFilter);
  }

  /**
   * Unregisters network state monitor
   */
  private void unregisterNetworkStateMonitor(){
    context.unregisterReceiver(networkStateReceiver);
  }

  @Override
  public void onDestroy() {
    unregisterNetworkStateMonitor();
  }

  @SimpleEvent(description = "反馈网络状态，参数的值为以下字符串：WIFI、2G、3G、4G、未连接网络、未知网络")
  public void NetworkState(String state) {
    EventDispatcher.dispatchEvent(this, "NetworkState", state);
  }

  @SimpleFunction(description = "获取网络状态，返回值为以下字符串：WIFI、2G、3G、4G、未连接网络、未知网络")
  public String GetNetworkState() {
    return getNetworkState(context);
  }

}