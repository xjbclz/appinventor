// -*- mode: java; c-basic-offset: 2; -*-
// Copyright 2009-2011 Google, All Rights reserved
// Copyright 2011-2012 MIT, All rights reserved
// Released under the Apache License, Version 2.0
// http://www.apache.org/licenses/LICENSE-2.0

package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.common.YaVersion;
import com.google.appinventor.components.runtime.util.TextViewUtil;
import com.google.appinventor.components.runtime.util.MediaUtil;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Typeface;

import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.SubscriptSpan;
import android.text.style.SuperscriptSpan;
import android.text.style.URLSpan;
import android.text.style.UnderlineSpan;
import android.text.style.AbsoluteSizeSpan;

import java.io.IOException;

/**
 * Label containing a text string.
 *
 */
@DesignerComponent(version = YaVersion.LABEL_COMPONENT_VERSION,
    description = "A Label displays a piece of text, which is " +
    "specified through the <code>Text</code> property.  Other properties, " +
    "all of which can be set in the Designer or Blocks Editor, control " +
    "the appearance and placement of the text.",
    category = ComponentCategory.USERINTERFACE)
@SimpleObject
public final class Label extends AndroidViewComponent implements OnClickListener {

  // default margin around a label in DPs
  // note that the spacing between adjacent labels will be twice this value
  // because each label has a margin
  private static final int DEFAULT_LABEL_MARGIN = 2;

  // default margin in density-independent pixels. This must be
  // computed using the view
  private int defaultLabelMarginInDp = 0;

  private final TextView view;

  private final LinearLayout.LayoutParams linearLayoutParams;

  // Backing for text alignment
  private int textAlignment;

  // Backing for background color
  private int backgroundColor;

  // Backing for font typeface
  private int fontTypeface;

  // Backing for font bold
  private boolean bold;

  // Backing for font italic
  private boolean italic;

  // Whether or not the label should have a margin
  private boolean hasMargins;

  // Backing for text color
  private int textColor;

  // Label Format
  private boolean htmlFormat;

  //qz
  private boolean textIsSelectable;

  private boolean multiLine;

  private SpannableString spannableString;

  private String picturePath = "";

  /**
   * Creates a new Label component.
   *
   * @param container  container, component will be placed in
   */
  public Label(ComponentContainer container) {
    super(container);
    view = new TextView(container.$context());

    // Adds the component to its designated container
    container.$add(this);

    // Get the layout parameters to use in setting margins (and potentially
    // other things.
    // There will be a bug if the label view does not have linear layout params.
    // TODO(hal): Generalize this for other types of layouts
    Object lp = view.getLayoutParams();
    // The following instanceof check will fail if we have not previously
    // added the label to the container (Why?)
    if (lp instanceof LinearLayout.LayoutParams) {
        linearLayoutParams = (LinearLayout.LayoutParams) lp;
        defaultLabelMarginInDp = dpToPx(view, DEFAULT_LABEL_MARGIN);
    } else {
      defaultLabelMarginInDp = 0;
      linearLayoutParams = null;
      Log.e("Label", "Error: The label's view does not have linear layout parameters");
      new RuntimeException().printStackTrace();
    }

    //qz
    view.setOnClickListener(this);

    // Default property values
    TextAlignment(Component.ALIGNMENT_NORMAL);
    BackgroundColor(Component.COLOR_NONE);
    fontTypeface = Component.TYPEFACE_DEFAULT;
    TextViewUtil.setFontTypeface(view, fontTypeface, bold, italic);
    FontSize(Component.FONT_DEFAULT_SIZE);
    Text("");
    TextColor(Component.COLOR_BLACK);
    HTMLFormat(false);
    HasMargins(true);
  }

  // put this in the right file
  private static int dpToPx(View view, int dp) {
    float density = view.getContext().getResources().getDisplayMetrics().density;
    return Math.round((float)dp * density);
  }

  @Override
  public View getView() {
    return view;
  }

  /**
   * Returns the alignment of the label's text: center, normal
   * (e.g., left-justified if text is written left to right), or
   * opposite (e.g., right-justified if text is written left to right).
   *
   * @return  one of {@link Component#ALIGNMENT_NORMAL},
   *          {@link Component#ALIGNMENT_CENTER} or
   *          {@link Component#ALIGNMENT_OPPOSITE}
   */
  @SimpleProperty(
      category = PropertyCategory.APPEARANCE,
      userVisible = false)
  public int TextAlignment() {
    return textAlignment;
  }

  /**
   * Specifies the alignment of the label's text: center, normal
   * (e.g., left-justified if text is written left to right), or
   * opposite (e.g., right-justified if text is written left to right).
   *
   * @param alignment  one of {@link Component#ALIGNMENT_NORMAL},
   *                   {@link Component#ALIGNMENT_CENTER} or
   *                   {@link Component#ALIGNMENT_OPPOSITE}
   */
  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_TEXTALIGNMENT,
      defaultValue = Component.ALIGNMENT_NORMAL + "")
  @SimpleProperty(
      userVisible = false)
  public void TextAlignment(int alignment) {
    this.textAlignment = alignment;
    TextViewUtil.setAlignment(view, alignment, false);
  }

  /**
   * Returns the label's background color as an alpha-red-green-blue
   * integer.
   *
   * @return  background RGB color with alpha
   */
  @SimpleProperty(
      category = PropertyCategory.APPEARANCE)
  public int BackgroundColor() {
    return backgroundColor;
  }

  /**
   * Specifies the label's background color as an alpha-red-green-blue
   * integer.
   *
   * @param argb  background RGB color with alpha
   */
  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_COLOR,
      defaultValue = Component.DEFAULT_VALUE_COLOR_NONE)
  @SimpleProperty
  public void BackgroundColor(int argb) {
    backgroundColor = argb;
    if (argb != Component.COLOR_DEFAULT) {
      TextViewUtil.setBackgroundColor(view, argb);
    } else {
      TextViewUtil.setBackgroundColor(view, Component.COLOR_NONE);
    }
  }

  /**
   * Returns true if the label's text should be bold.
   * If bold has been requested, this property will return true, even if the
   * font does not support bold.
   *
   * @return  {@code true} indicates bold, {@code false} normal
   */
  @SimpleProperty(
      category = PropertyCategory.APPEARANCE,
      userVisible = false)
  public boolean FontBold() {
    return bold;
  }

  /**
   * Specifies whether the label's text should be bold.
   * Some fonts do not support bold.
   *
   * @param bold  {@code true} indicates bold, {@code false} normal
   */
  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_BOOLEAN,
      defaultValue = "False")
  @SimpleProperty(
      userVisible = false)
  public void FontBold(boolean bold) {
    this.bold = bold;
    TextViewUtil.setFontTypeface(view, fontTypeface, bold, italic);
  }

  /**
   * Returns true if the label's text should be italic.
   * If italic has been requested, this property will return true, even if the
   * font does not support italic.
   *
   * @return  {@code true} indicates italic, {@code false} normal
   */
  @SimpleProperty(
      category = PropertyCategory.APPEARANCE,
      userVisible = false)
  public boolean FontItalic() {
    return italic;
  }

  /**
   * Specifies whether the label's text should be italic.
   * Some fonts do not support italic.
   *
   * @param italic  {@code true} indicates italic, {@code false} normal
   */
  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_BOOLEAN,
      defaultValue = "False")
  @SimpleProperty(
      userVisible = false)
  public void FontItalic(boolean italic) {
    this.italic = italic;
    TextViewUtil.setFontTypeface(view, fontTypeface, bold, italic);
  }

  /**
   * Returns true if the label should have  margins.
   *
   * @return  {@code true} indicates margins, {@code false} no margins
   */
  @SimpleProperty(
      category = PropertyCategory.APPEARANCE,
      description = "Reports whether or not the label appears with margins.  All four "
      + "margins (left, right, top, bottom) are the same.  This property has no effect "
      + "in the designer, where labels are always shown with margins.",
      userVisible = true)
  public boolean HasMargins() {
    return hasMargins;
  }

  /**
   * Specifies whether the label should have margins.
   * This margin value is not well coordinated with the
   * designer, where the margins are defined for the arrangement, not just for individual
   * labels.
   *
   * @param hasMargins {@code true} indicates that there are margins, {@code false} no margins
   */
  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_BOOLEAN,
      defaultValue = "True")
  @SimpleProperty(
      userVisible = true)
  public void HasMargins(boolean hasMargins) {
    this.hasMargins = hasMargins;
    setLabelMargins(hasMargins);
  }

private void setLabelMargins(boolean hasMargins) {
  int m = hasMargins ? defaultLabelMarginInDp : 0 ;
  linearLayoutParams.setMargins(m, m, m, m);
  view.invalidate();
}

  /**
   * Returns the label's text's font size, measured in sp(scale-independent pixels).
   *
   * @return  font size in sp(scale-independent pixels).
   */
  @SimpleProperty(
      category = PropertyCategory.APPEARANCE)
  public float FontSize() {
    return TextViewUtil.getFontSize(view, container.$context());
  }

  /**
   * Specifies the label's text's font size, measured in sp(scale-independent pixels).
   *
   * @param size  font size in sp (scale-independent pixels)
   */
  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_NON_NEGATIVE_FLOAT,
      defaultValue = Component.FONT_DEFAULT_SIZE + "")
  @SimpleProperty
  public void FontSize(float size) {
    TextViewUtil.setFontSize(view, size);
  }

  /**
   * Returns the label's text's font face as default, serif, sans
   * serif, or monospace.
   *
   * @return  one of {@link Component#TYPEFACE_DEFAULT},
   *          {@link Component#TYPEFACE_SERIF},
   *          {@link Component#TYPEFACE_SANSSERIF} or
   *          {@link Component#TYPEFACE_MONOSPACE}
   */
  @SimpleProperty(
      category = PropertyCategory.APPEARANCE,
      userVisible = false)
  public int FontTypeface() {
    return fontTypeface;
  }

  /**
   * Specifies the label's text's font face as default, serif, sans
   * serif, or monospace.
   *
   * @param typeface  one of {@link Component#TYPEFACE_DEFAULT},
   *                  {@link Component#TYPEFACE_SERIF},
   *                  {@link Component#TYPEFACE_SANSSERIF} or
   *                  {@link Component#TYPEFACE_MONOSPACE}
   */
  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_TYPEFACE,
      defaultValue = Component.TYPEFACE_DEFAULT + "")
  @SimpleProperty(
      userVisible = false)
  public void FontTypeface(int typeface) {
    fontTypeface = typeface;
    TextViewUtil.setFontTypeface(view, fontTypeface, bold, italic);
  }

  /**
   * Returns the text displayed by the label.
   *
   * @return  label caption
   */
  @SimpleProperty(
      category = PropertyCategory.APPEARANCE)
  public String Text() {
    return TextViewUtil.getText(view);
  }

  /**
   * Specifies the text displayed by the label.
   *
   * @param text  new caption for label
   */
  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_STRING,
      defaultValue = "")
  @SimpleProperty
  public void Text(String text) {
    if (htmlFormat) {
      TextViewUtil.setTextHTML(view, text);
    } else {
      TextViewUtil.setText(view, text);
    }
  }


  /**
   * Returns the label's text's format
   *
   * @return {@code true} indicates that the label format is html text
   *         {@code false} lines that the label format is plain text
   */
  @SimpleProperty(
      category = PropertyCategory.APPEARANCE,
      description = "If true, then this label will show html text else it " +
      "will show plain text. Note: Not all HTML is supported.")
  public boolean HTMLFormat() {
    return htmlFormat;
  }

  /**
   * Specifies the label's text's format
   *
   * @return {@code true} indicates that the label format is html text
   *         {@code false} lines that the label format is plain text
   */
  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_BOOLEAN,
      defaultValue = "False")
  @SimpleProperty(userVisible = false)
  public void HTMLFormat(boolean fmt) {
    htmlFormat = fmt;
    if (htmlFormat) {
      String txt = TextViewUtil.getText(view);
      TextViewUtil.setTextHTML(view, txt);
    } else {
      String txt = TextViewUtil.getText(view);
      TextViewUtil.setText(view, txt);
    }
  }

  /**
   * Returns the label's text color as an alpha-red-green-blue
   * integer.
   *
   * @return  text RGB color with alpha
   */
  @SimpleProperty(
      category = PropertyCategory.APPEARANCE)
  public int TextColor() {
    return textColor;
  }

  /**
   * Specifies the label's text color as an alpha-red-green-blue
   * integer.
   *
   * @param argb  text RGB color with alpha
   */
  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_COLOR,
      defaultValue = Component.DEFAULT_VALUE_COLOR_BLACK)
  @SimpleProperty
  public void TextColor(int argb) {
    textColor = argb;
    if (argb != Component.COLOR_DEFAULT) {
      TextViewUtil.setTextColor(view, argb);
    } else {
      TextViewUtil.setTextColor(view, Component.COLOR_BLACK);
    }
  }

  //qz
  @Override
  public void onClick(View view) {
    Click();
  }

  @SimpleProperty(
    category = PropertyCategory.BEHAVIOR,
    description = "设置标签文本是否可被选中复制")
  public boolean TextIsSelectable() {
    return textIsSelectable;
  }

  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_BOOLEAN,
    defaultValue = "False")
  @SimpleProperty
  public void TextIsSelectable(boolean textIsSelectable) {
    this.textIsSelectable = textIsSelectable;
    TextViewUtil.setTextIsSelectable(view, textIsSelectable);
  }

  @SimpleProperty(
    category = PropertyCategory.BEHAVIOR,
    description = "允许多行")
  public boolean MultiLine() {
    return multiLine;
  }

  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_BOOLEAN, defaultValue = "True")
  @SimpleProperty
  public void MultiLine(boolean multiLine) {
    this.multiLine = multiLine;
    TextViewUtil.setSingleLine(view, !multiLine);
  }

  @SimpleEvent(description = "用户点击标签事件的响应函数")
  public void Click() {
    EventDispatcher.dispatchEvent(this, "Click");
  }

  @SimpleFunction(description = "跑马灯效果")
  public void Marquee() {
    TextViewUtil.setMarquee(view);
  }

  @SimpleFunction(description = "设置在标签的上下左右四边显示的图片")
  public void SetLabelDrawable(String path, int width, int height, boolean left, boolean top, boolean right, boolean bottom) {
    Drawable drawable = null;
    Drawable drawableLeft = null;
    Drawable drawableTop = null;
    Drawable drawableRight = null;
    Drawable drawableBottom = null;

    String picturePath = (path == null) ? "" : path;
    
    try {
      drawable = MediaUtil.getBitmapDrawable(container.$form(), picturePath);
    } catch (IOException ioe) {
      Log.e("Label", "Unable to load " + picturePath);

      drawable = null;
    }
    
    if (drawable != null){
      int correctedWidth = (int)(width * container.$form().deviceDensity());
      int correctedHeight = (int)(height * container.$form().deviceDensity());
      drawable.setBounds(0, 0, correctedWidth, correctedHeight);

      if (left){
        drawableLeft = drawable;
      }

      if (top){
        drawableTop = drawable;
      }

      if (right){
        drawableRight = drawable;
      }

      if (bottom){
        drawableBottom = drawable;
      }

      view.setCompoundDrawables(drawableLeft, drawableTop, drawableRight, drawableBottom);
      view.requestLayout();
    }
  }

  @SimpleFunction(description = "创建富文本")
  public void CreateSpannableString(String text) {
    spannableString = new SpannableString(text);
  }

  @SimpleFunction(description = "设置富文本的前景色")
  public void SetForegroundColor(int color, int startIndex, int endIndex) {
    ForegroundColorSpan foregroundColorSpan = new ForegroundColorSpan(color);
    spannableString.setSpan(foregroundColorSpan, startIndex, endIndex, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
  }

  @SimpleFunction(description = "设置富文本的背景色")
  public void SetBackgroundColor(int color, int startIndex, int endIndex) {
    BackgroundColorSpan backgroundColorSpan = new BackgroundColorSpan(color);
    spannableString.setSpan(backgroundColorSpan, startIndex, endIndex, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
  }

  @SimpleFunction(description = "设置富文本文字的字号")
  public void SetAbsoluteSize(int size, int startIndex, int endIndex) {
    AbsoluteSizeSpan absoluteSizeSpan = new AbsoluteSizeSpan(size, true);
    spannableString.setSpan(absoluteSizeSpan, startIndex, endIndex, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
  }

  @SimpleFunction(description = "设置富文本文字的字体为粗体")
  public void SetStyleBold(int startIndex, int endIndex) {
    StyleSpan styleSpan = new StyleSpan(Typeface.BOLD);
    spannableString.setSpan(styleSpan, startIndex, endIndex, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
  }

  @SimpleFunction(description = "设置富文本文字的删除线")
  public void SetStrikethrough(int startIndex, int endIndex) {
    StrikethroughSpan strikethroughSpan = new StrikethroughSpan();
    spannableString.setSpan(strikethroughSpan, startIndex, endIndex, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
  }

  @SimpleFunction(description = "设置富文本文字的下划线")
  public void SetUnderline(int startIndex, int endIndex) {
    UnderlineSpan underlineSpan = new UnderlineSpan();
    spannableString.setSpan(underlineSpan, startIndex, endIndex, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
  }

  @SimpleFunction(description = "设置富文本文字的上标")
  public void SetSuperscript(int startIndex, int endIndex) {
    SuperscriptSpan superscriptSpan = new SuperscriptSpan();
    spannableString.setSpan(superscriptSpan, startIndex, endIndex, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
  }

  @SimpleFunction(description = "设置富文本文字的下标")
  public void SetSubscript(int startIndex, int endIndex) {
    SubscriptSpan subscriptSpan = new SubscriptSpan();
    spannableString.setSpan(subscriptSpan, startIndex, endIndex, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
  }

  @SimpleFunction(description = "设置富文本文字的超级链接，行为参数的值为：打电话、发短信、打开网页")
  public void SetURL(String action, String text, int startIndex, int endIndex) {
    URLSpan urlSpan;

    if (action.equals("打电话")) {
      urlSpan = new URLSpan("tel:" + text);
      spannableString.setSpan(urlSpan, startIndex, endIndex, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
      view.setMovementMethod(LinkMovementMethod.getInstance());
    }

    if (action.equals("发短信")) {
      urlSpan = new URLSpan("smsto:" + text);
      spannableString.setSpan(urlSpan, startIndex, endIndex, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
      view.setMovementMethod(LinkMovementMethod.getInstance());
    }

    if (action.equals("打开网页")) {
      urlSpan = new URLSpan(text);
      spannableString.setSpan(urlSpan, startIndex, endIndex, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
      view.setMovementMethod(LinkMovementMethod.getInstance());
    }
  }

  @SimpleFunction(description = "富文本中插入图片，width和height是图片显示区域的宽度和高度")
  public void SetImage(String path, int width, int height, int startIndex, int endIndex) {
    picturePath = (path == null) ? "" : path;

    Drawable drawable;
    try {
      drawable = MediaUtil.getBitmapDrawable(container.$form(), picturePath);
    } catch (IOException ioe) {
      Log.e("Image", "Unable to load " + picturePath);
      drawable = null;
    }

    int correctedWidth = (int)(width * container.$form().deviceDensity());
    int correctedHeight = (int)(height * container.$form().deviceDensity());

    drawable.setBounds(0, 0, correctedWidth, correctedHeight);
    ImageSpan imageSpan = new ImageSpan(drawable);
    spannableString.setSpan(imageSpan, startIndex, endIndex, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
  }

  @SimpleFunction(description = "设置富文本为标签内容")
  public void SetSpannableString() {
    view.setText(spannableString);
    view.requestLayout();
  }
}
